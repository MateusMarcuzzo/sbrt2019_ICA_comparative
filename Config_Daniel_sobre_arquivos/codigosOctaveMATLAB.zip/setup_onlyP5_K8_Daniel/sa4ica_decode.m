

%SA4ICA Probabilities Tensor version - Prime fields only!
%Good for large number of samples - 2^11 or larger!!!
function [B] = sa4ica_decode(Px,parameters,beta,k)

epsilon = 1e-3;

N = parameters.K;
q = parameters.P;

B = eye(N,N); %initial solution
[h, ~] = decode_(eye(N),Px,parameters); %initial entropies


T = 1; %Kirckpatrick

while T>epsilon
    ij = round((N-1)*rand(2,k)) + 1;
    c = round((q-2)*rand(1,k)) + 1;
    for it=1:k
        %generate a random moveZ
        V = eye(N);
        V(ij(1,it),ij(2,it)) = c(it);  %switch Xi by the combination Xi + c.Xj

        [hnew, Pxnew] = decode_(V, Px, parameters);
        hnew = hnew(ij(1,it));
        delta_H = hnew - h(ij(1,it));
        %update candidate solution
        if(delta_H<0 || exp(-delta_H/T) > rand())
            B = produtomatrizGF(V,B,q,1,[]);
            Px = Pxnew;
            h(ij(1,it)) = hnew;
        end
    end
    T = beta * T;
%     fprintf(1,'%d %.4f\n', Nit, T);
end
end
